package com.example.notesapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditNoteActivity extends AppCompatActivity {

    private EditText noteEditText;
    private Button saveNoteBtn;
    private int notePosition;
    private Button deleteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_note);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        noteEditText = findViewById(R.id.noteEditText);
        saveNoteBtn = findViewById(R.id.saveBtn);
        deleteBtn = findViewById(R.id.deleteBtn);

        Intent intent = getIntent();
        String ogNote = intent.getStringExtra("note");
        notePosition = intent.getIntExtra("position", -1);

        noteEditText.setText(ogNote);
    }
    public void saveNote(View view) {
        String newNote = noteEditText.getText().toString();
        Intent resultIntent = new Intent();
        resultIntent.putExtra("note", newNote);
        resultIntent.putExtra("position", notePosition);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    public void deleteNote(View view) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("position", notePosition);
        setResult(RESULT_CANCELED, resultIntent);
        finish();
    }
}